<?php 

$person = [
    'id' => 1,
    'name' => 'Sebastian',
];

echo $person["name"];

