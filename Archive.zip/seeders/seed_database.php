<?php

require_once __DIR__.'/seed_roles.php';
require_once __DIR__.'/seed_users.php';
require_once __DIR__.'/seed_items.php';
require_once __DIR__.'/seed_orders.php';
require_once __DIR__.'/seed_orders_items.php';
require_once __DIR__.'/seed_employees.php';


















